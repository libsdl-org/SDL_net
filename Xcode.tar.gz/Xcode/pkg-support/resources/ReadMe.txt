This is an example portable network library for use with SDL.

The default install location for the framework is /Library/Frameworks

The API can be found in the file /Library/Frameworks/SDL_net.framework/Headers/SDL_net.h

The source code is available from: http://www.libsdl.org/projects/SDL_net

This library is distributed under the terms of the GNU LGPL license: http://www.gnu.org/copyleft/lesser.html
